<?php
$dbhost = 'localhost';
$dbuser = 'ChrisJones';
$dbpass = 'Kenshin1989!';
$dbname = 'beardedbrowncoats';
?>
